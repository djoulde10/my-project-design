export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      actions: {
        Row: {
          completion_date: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          notes: string | null
          responsible_member_id: string | null
          solution_id: string
          status: Database["public"]["Enums"]["action_status"]
          title: string
          updated_at: string
        }
        Insert: {
          completion_date?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          responsible_member_id?: string | null
          solution_id: string
          status?: Database["public"]["Enums"]["action_status"]
          title: string
          updated_at?: string
        }
        Update: {
          completion_date?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          responsible_member_id?: string | null
          solution_id?: string
          status?: Database["public"]["Enums"]["action_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "actions_decision_id_fkey"
            columns: ["solution_id"]
            isOneToOne: false
            referencedRelation: "solutions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "actions_responsible_member_id_fkey"
            columns: ["responsible_member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
        ]
      }
      agenda_items: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_confidential: boolean
          nature: Database["public"]["Enums"]["agenda_nature"]
          order_index: number
          presenter_member_id: string | null
          session_id: string
          title: string
          validated_by_president: boolean
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_confidential?: boolean
          nature?: Database["public"]["Enums"]["agenda_nature"]
          order_index?: number
          presenter_member_id?: string | null
          session_id: string
          title: string
          validated_by_president?: boolean
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_confidential?: boolean
          nature?: Database["public"]["Enums"]["agenda_nature"]
          order_index?: number
          presenter_member_id?: string | null
          session_id?: string
          title?: string
          validated_by_president?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "agenda_items_presenter_member_id_fkey"
            columns: ["presenter_member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agenda_items_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: string
          new_values: Json | null
          old_values: Json | null
          record_id: string | null
          table_name: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      documents: {
        Row: {
          agenda_item_id: string | null
          created_at: string
          file_path: string
          file_size: number | null
          id: string
          is_confidential: boolean
          mime_type: string | null
          name: string
          session_id: string | null
          uploaded_by: string | null
          version: number
        }
        Insert: {
          agenda_item_id?: string | null
          created_at?: string
          file_path: string
          file_size?: number | null
          id?: string
          is_confidential?: boolean
          mime_type?: string | null
          name: string
          session_id?: string | null
          uploaded_by?: string | null
          version?: number
        }
        Update: {
          agenda_item_id?: string | null
          created_at?: string
          file_path?: string
          file_size?: number | null
          id?: string
          is_confidential?: boolean
          mime_type?: string | null
          name?: string
          session_id?: string | null
          uploaded_by?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "documents_agenda_item_id_fkey"
            columns: ["agenda_item_id"]
            isOneToOne: false
            referencedRelation: "agenda_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      members: {
        Row: {
          created_at: string
          email: string | null
          full_name: string
          id: string
          is_active: boolean
          mandate_end: string | null
          mandate_start: string
          organ_id: string
          phone: string | null
          quality: Database["public"]["Enums"]["member_quality"]
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          is_active?: boolean
          mandate_end?: string | null
          mandate_start: string
          organ_id: string
          phone?: string | null
          quality?: Database["public"]["Enums"]["member_quality"]
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          is_active?: boolean
          mandate_end?: string | null
          mandate_start?: string
          organ_id?: string
          phone?: string | null
          quality?: Database["public"]["Enums"]["member_quality"]
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "members_organ_id_fkey"
            columns: ["organ_id"]
            isOneToOne: false
            referencedRelation: "organs"
            referencedColumns: ["id"]
          },
        ]
      }
      minutes: {
        Row: {
          content: string | null
          created_at: string
          id: string
          is_validated: boolean
          pdf_path: string | null
          pv_status: string
          session_id: string
          updated_at: string
          validated_at: string | null
          validated_by: string | null
        }
        Insert: {
          content?: string | null
          created_at?: string
          id?: string
          is_validated?: boolean
          pdf_path?: string | null
          pv_status?: string
          session_id: string
          updated_at?: string
          validated_at?: string | null
          validated_by?: string | null
        }
        Update: {
          content?: string | null
          created_at?: string
          id?: string
          is_validated?: boolean
          pdf_path?: string | null
          pv_status?: string
          session_id?: string
          updated_at?: string
          validated_at?: string | null
          validated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "minutes_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      organs: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          type: Database["public"]["Enums"]["organ_type"]
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          type: Database["public"]["Enums"]["organ_type"]
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          type?: Database["public"]["Enums"]["organ_type"]
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      session_attendees: {
        Row: {
          id: string
          is_present: boolean | null
          member_id: string
          proxy_member_id: string | null
          session_id: string
        }
        Insert: {
          id?: string
          is_present?: boolean | null
          member_id: string
          proxy_member_id?: string | null
          session_id: string
        }
        Update: {
          id?: string
          is_present?: boolean | null
          member_id?: string
          proxy_member_id?: string | null
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_attendees_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_attendees_proxy_member_id_fkey"
            columns: ["proxy_member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_attendees_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      sessions: {
        Row: {
          convocation_sent: boolean
          created_at: string
          created_by: string | null
          id: string
          is_virtual: boolean
          location: string | null
          organ_id: string
          quorum_met: boolean | null
          session_date: string
          session_type: Database["public"]["Enums"]["session_type"]
          status: Database["public"]["Enums"]["session_status"]
          title: string
          updated_at: string
        }
        Insert: {
          convocation_sent?: boolean
          created_at?: string
          created_by?: string | null
          id?: string
          is_virtual?: boolean
          location?: string | null
          organ_id: string
          quorum_met?: boolean | null
          session_date: string
          session_type?: Database["public"]["Enums"]["session_type"]
          status?: Database["public"]["Enums"]["session_status"]
          title: string
          updated_at?: string
        }
        Update: {
          convocation_sent?: boolean
          created_at?: string
          created_by?: string | null
          id?: string
          is_virtual?: boolean
          location?: string | null
          organ_id?: string
          quorum_met?: boolean | null
          session_date?: string
          session_type?: Database["public"]["Enums"]["session_type"]
          status?: Database["public"]["Enums"]["session_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sessions_organ_id_fkey"
            columns: ["organ_id"]
            isOneToOne: false
            referencedRelation: "organs"
            referencedColumns: ["id"]
          },
        ]
      }
      solutions: {
        Row: {
          agenda_item_id: string | null
          created_at: string
          date_effet: string | null
          id: string
          numero_solution: string
          responsable_execution_id: string | null
          session_id: string
          texte: string
          vote_type: Database["public"]["Enums"]["vote_type"] | null
        }
        Insert: {
          agenda_item_id?: string | null
          created_at?: string
          date_effet?: string | null
          id?: string
          numero_solution: string
          responsable_execution_id?: string | null
          session_id: string
          texte: string
          vote_type?: Database["public"]["Enums"]["vote_type"] | null
        }
        Update: {
          agenda_item_id?: string | null
          created_at?: string
          date_effet?: string | null
          id?: string
          numero_solution?: string
          responsable_execution_id?: string | null
          session_id?: string
          texte?: string
          vote_type?: Database["public"]["Enums"]["vote_type"] | null
        }
        Relationships: [
          {
            foreignKeyName: "decisions_agenda_item_id_fkey"
            columns: ["agenda_item_id"]
            isOneToOne: false
            referencedRelation: "agenda_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "decisions_responsible_member_id_fkey"
            columns: ["responsable_execution_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "decisions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      action_status: "en_cours" | "en_retard" | "terminee" | "annulee"
      agenda_nature: "information" | "decision"
      app_role:
        | "admin"
        | "secretaire"
        | "president"
        | "membre"
        | "invite"
        | "auditeur"
      member_quality:
        | "pca"
        | "administrateur"
        | "president_comite"
        | "rapporteur"
        | "membre"
        | "autre"
        | "secretariat_juridique"
      minutes_status: "en_attente" | "vote" | "adopte" | "adopte_et_signe"
      organ_type: "ca" | "comite_audit"
      session_status:
        | "brouillon"
        | "validee"
        | "tenue"
        | "cloturee"
        | "archivee"
      session_type: "ordinaire" | "extraordinaire"
      vote_type: "unanimite" | "majorite" | "abstention"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      action_status: ["en_cours", "en_retard", "terminee", "annulee"],
      agenda_nature: ["information", "decision"],
      app_role: [
        "admin",
        "secretaire",
        "president",
        "membre",
        "invite",
        "auditeur",
      ],
      member_quality: [
        "pca",
        "administrateur",
        "president_comite",
        "rapporteur",
        "membre",
        "autre",
        "secretariat_juridique",
      ],
      minutes_status: ["en_attente", "vote", "adopte", "adopte_et_signe"],
      organ_type: ["ca", "comite_audit"],
      session_status: ["brouillon", "validee", "tenue", "cloturee", "archivee"],
      session_type: ["ordinaire", "extraordinaire"],
      vote_type: ["unanimite", "majorite", "abstention"],
    },
  },
} as const
