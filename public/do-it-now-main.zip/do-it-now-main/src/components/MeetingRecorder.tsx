import { useState, useCallback, useRef } from "react";
import { useScribe, CommitStrategy } from "@elevenlabs/react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Mic, MicOff, Sparkles, Loader2, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MeetingRecorderProps {
  onSummaryGenerated: (summary: string) => void;
}

export default function MeetingRecorder({ onSummaryGenerated }: MeetingRecorderProps) {
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [fullTranscript, setFullTranscript] = useState("");
  const [copied, setCopied] = useState(false);
  const transcriptRef = useRef("");

  const scribe = useScribe({
    modelId: "scribe_v2_realtime",
    commitStrategy: "vad" as any,
    onCommittedTranscript: (data) => {
      transcriptRef.current += (transcriptRef.current ? " " : "") + data.text;
      setFullTranscript(transcriptRef.current);
    },
  });

  const handleStart = useCallback(async () => {
    setIsConnecting(true);
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });

      const { data, error } = await supabase.functions.invoke("elevenlabs-scribe-token");
      if (error || !data?.token) {
        throw new Error(error?.message || "Impossible d'obtenir le token");
      }

      await scribe.connect({
        token: data.token,
        microphone: {
          echoCancellation: true,
          noiseSuppression: true,
        },
      });
    } catch (e: any) {
      console.error("Start error:", e);
      toast({
        title: "Erreur micro",
        description: e.message || "Impossible de démarrer l'enregistrement",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  }, [scribe, toast]);

  const handleStop = useCallback(() => {
    scribe.disconnect();
  }, [scribe]);

  const handleSummarize = async () => {
    if (!fullTranscript.trim()) {
      toast({ title: "Aucune transcription", description: "Enregistrez d'abord une réunion.", variant: "destructive" });
      return;
    }
    setIsSummarizing(true);
    try {
      const { data, error } = await supabase.functions.invoke("summarize-meeting", {
        body: { transcript: fullTranscript },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      onSummaryGenerated(data.summary);
      toast({ title: "PV généré avec succès !" });
    } catch (e: any) {
      toast({ title: "Erreur IA", description: e.message, variant: "destructive" });
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(fullTranscript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    transcriptRef.current = "";
    setFullTranscript("");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Mic className="w-5 h-5" />
          Enregistrement de la réunion
          {scribe.isConnected && (
            <Badge variant="default" className="animate-pulse bg-destructive">
              ● En cours
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Controls */}
        <div className="flex flex-wrap gap-2">
          {!scribe.isConnected ? (
            <Button onClick={handleStart} disabled={isConnecting}>
              {isConnecting ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Connexion...</>
              ) : (
                <><Mic className="w-4 h-4 mr-2" />Démarrer l'écoute</>
              )}
            </Button>
          ) : (
            <Button variant="destructive" onClick={handleStop}>
              <MicOff className="w-4 h-4 mr-2" />Arrêter
            </Button>
          )}

          <Button
            variant="secondary"
            onClick={handleSummarize}
            disabled={!fullTranscript.trim() || isSummarizing || scribe.isConnected}
          >
            {isSummarizing ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Génération du PV...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" />Générer le PV</>
            )}
          </Button>

          {fullTranscript && (
            <>
              <Button variant="outline" size="icon" onClick={handleCopy}>
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" onClick={handleReset} disabled={scribe.isConnected}>
                Réinitialiser
              </Button>
            </>
          )}
        </div>

        {/* Live partial */}
        {scribe.isConnected && scribe.partialTranscript && (
          <p className="text-sm text-muted-foreground italic animate-pulse">
            {scribe.partialTranscript}
          </p>
        )}

        {/* Transcript */}
        {fullTranscript && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">
              Transcription ({fullTranscript.split(" ").length} mots)
            </p>
            <Textarea
              readOnly
              value={fullTranscript}
              className="min-h-[150px] text-sm"
            />
          </div>
        )}

        {!fullTranscript && !scribe.isConnected && (
          <p className="text-sm text-muted-foreground">
            Cliquez sur "Démarrer l'écoute" pour transcrire la réunion en temps réel. 
            Une fois terminé, l'IA générera automatiquement un procès-verbal structuré.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
