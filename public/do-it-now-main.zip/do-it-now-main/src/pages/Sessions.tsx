import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, CalendarDays, MapPin, Video, FileUp, Trash2, Eye, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const statusColors: Record<string, string> = {
  brouillon: "bg-muted text-muted-foreground",
  validee: "bg-primary/10 text-primary",
  tenue: "bg-amber-100 text-amber-800",
  cloturee: "bg-emerald-100 text-emerald-800",
  archivee: "bg-muted text-muted-foreground",
};
const statusLabels: Record<string, string> = {
  brouillon: "Brouillon", validee: "Validée", tenue: "Tenue", cloturee: "Clôturée", archivee: "Archivée",
};

interface AgendaItemDraft {
  title: string;
  description: string;
  nature: "information" | "decision";
  files: File[];
}

export default function Sessions() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sessions, setSessions] = useState<any[]>([]);
  const [organs, setOrgans] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [expandedSession, setExpandedSession] = useState<string | null>(null);
  const [sessionDetails, setSessionDetails] = useState<Record<string, { agendaItems: any[]; attendees: any[] }>>({});

  // Create form
  const [form, setForm] = useState({
    organ_id: "", title: "", session_type: "ordinaire" as "ordinaire" | "extraordinaire",
    session_date: "", location: "", is_virtual: false,
  });
  const [agendaDrafts, setAgendaDrafts] = useState<AgendaItemDraft[]>([]);

  const fetchSessions = async () => {
    const { data } = await supabase
      .from("sessions")
      .select("*, organs(name, type)")
      .order("session_date", { ascending: false });
    setSessions(data ?? []);
  };

  const fetchOrgans = async () => {
    const { data } = await supabase.from("organs").select("*");
    setOrgans(data ?? []);
  };

  useEffect(() => { fetchSessions(); fetchOrgans(); }, []);

  const addAgendaItem = () => {
    setAgendaDrafts([...agendaDrafts, { title: "", description: "", nature: "information", files: [] }]);
  };

  const updateAgendaDraft = (idx: number, field: string, value: any) => {
    const updated = [...agendaDrafts];
    (updated[idx] as any)[field] = value;
    setAgendaDrafts(updated);
  };

  const addFileToAgenda = (idx: number, files: FileList | null) => {
    if (!files) return;
    const updated = [...agendaDrafts];
    updated[idx].files = [...updated[idx].files, ...Array.from(files)];
    setAgendaDrafts(updated);
  };

  const removeFileFromAgenda = (agendaIdx: number, fileIdx: number) => {
    const updated = [...agendaDrafts];
    updated[agendaIdx].files.splice(fileIdx, 1);
    setAgendaDrafts(updated);
  };

  const removeAgendaDraft = (idx: number) => {
    setAgendaDrafts(agendaDrafts.filter((_, i) => i !== idx));
  };

  const handleCreate = async () => {
    // 1. Create session
    const { data: session, error } = await supabase.from("sessions").insert([{
      ...form, created_by: user?.id,
    }]).select().single();
    if (error || !session) {
      toast({ title: "Erreur", description: error?.message, variant: "destructive" });
      return;
    }

    // 2. Create agenda items + upload docs
    for (let i = 0; i < agendaDrafts.length; i++) {
      const draft = agendaDrafts[i];
      if (!draft.title) continue;
      const { data: agendaItem, error: agErr } = await supabase.from("agenda_items").insert([{
        session_id: session.id,
        title: draft.title,
        description: draft.description || null,
        nature: draft.nature,
        order_index: i,
      }]).select().single();
      if (agErr || !agendaItem) continue;

      // Upload files
      for (const file of draft.files) {
        const filePath = `${session.id}/${agendaItem.id}/${Date.now()}_${file.name}`;
        const { error: upErr } = await supabase.storage.from("session-documents").upload(filePath, file);
        if (!upErr) {
          await supabase.from("documents").insert([{
            session_id: session.id,
            agenda_item_id: agendaItem.id,
            name: file.name,
            file_path: filePath,
            file_size: file.size,
            mime_type: file.type,
            uploaded_by: user?.id,
          }]);
        }
      }
    }

    // 3. Add organ members as attendees
    const { data: organMembers } = await supabase.from("members").select("id").eq("organ_id", form.organ_id).eq("is_active", true);
    if (organMembers && organMembers.length > 0) {
      await supabase.from("session_attendees").insert(
        organMembers.map((m) => ({ session_id: session.id, member_id: m.id }))
      );
    }

    toast({ title: "Session créée avec succès" });
    setOpen(false);
    setForm({ organ_id: "", title: "", session_type: "ordinaire", session_date: "", location: "", is_virtual: false });
    setAgendaDrafts([]);
    fetchSessions();
  };

  const toggleSessionDetails = async (sessionId: string) => {
    if (expandedSession === sessionId) {
      setExpandedSession(null);
      return;
    }
    setExpandedSession(sessionId);
    if (!sessionDetails[sessionId]) {
      const [agRes, attRes] = await Promise.all([
        supabase.from("agenda_items").select("*, documents(*)").eq("session_id", sessionId).order("order_index"),
        supabase.from("session_attendees").select("*, members(full_name, quality)").eq("session_id", sessionId),
      ]);
      setSessionDetails((prev) => ({
        ...prev,
        [sessionId]: { agendaItems: agRes.data ?? [], attendees: attRes.data ?? [] },
      }));
    }
  };

  const caOrgans = organs.filter((o) => o.type === "ca");
  const auditOrgans = organs.filter((o) => o.type === "comite_audit");
  const caSessions = sessions.filter((s) => (s as any).organs?.type === "ca");
  const auditSessions = sessions.filter((s) => (s as any).organs?.type === "comite_audit");

  const selectedOrgan = organs.find((o) => o.id === form.organ_id);
  const isAudit = selectedOrgan?.type === "comite_audit";

  const renderSessionsTable = (list: any[]) => (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead></TableHead>
              <TableHead>Session</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Lieu</TableHead>
              {!isAudit && <TableHead>Type</TableHead>}
              <TableHead>Statut</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {list.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                  Aucune session.
                </TableCell>
              </TableRow>
            ) : (
              list.map((s) => (
                <>
                  <TableRow key={s.id} className="cursor-pointer hover:bg-muted/50" onClick={() => toggleSessionDetails(s.id)}>
                    <TableCell className="w-8">
                      {expandedSession === s.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </TableCell>
                    <TableCell className="font-medium">{s.title}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-sm">
                        <CalendarDays className="w-3.5 h-3.5 text-muted-foreground" />
                        {new Date(s.session_date).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-sm">
                        {s.is_virtual ? <Video className="w-3.5 h-3.5" /> : <MapPin className="w-3.5 h-3.5" />}
                        {s.location ?? "—"}
                      </div>
                    </TableCell>
                    {(s as any).organs?.type !== "comite_audit" && (
                      <TableCell>
                        <Badge variant="outline" className="capitalize">{s.session_type}</Badge>
                      </TableCell>
                    )}
                    <TableCell>
                      <Badge className={statusColors[s.status] ?? ""}>{statusLabels[s.status] ?? s.status}</Badge>
                    </TableCell>
                  </TableRow>
                  {expandedSession === s.id && sessionDetails[s.id] && (
                    <TableRow key={`${s.id}-details`}>
                      <TableCell colSpan={6} className="bg-muted/30 p-4">
                        <SessionDetailsPanel details={sessionDetails[s.id]} sessionId={s.id} sessionStatus={s.status} onRefresh={() => {
                          setSessionDetails((prev) => {
                            const copy = { ...prev };
                            delete copy[s.id];
                            return copy;
                          });
                          toggleSessionDetails(s.id);
                        }} />
                      </TableCell>
                    </TableRow>
                  )}
                </>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Sessions</h1>
          <p className="text-muted-foreground">Gérez les sessions du CA et du Comité d'Audit</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" />Nouvelle session</Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Créer une session</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Organe</Label>
                <Select value={form.organ_id} onValueChange={(v) => setForm({ ...form, organ_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                  <SelectContent>
                    {organs.map((o) => (
                      <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Titre</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                {!isAudit && (
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select value={form.session_type} onValueChange={(v) => setForm({ ...form, session_type: v as "ordinaire" | "extraordinaire" })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ordinaire">Ordinaire</SelectItem>
                        <SelectItem value="extraordinaire">Extraordinaire</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div className="space-y-2">
                  <Label>Date & Heure</Label>
                  <Input type="datetime-local" value={form.session_date} onChange={(e) => setForm({ ...form, session_date: e.target.value })} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Lieu</Label>
                <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Salle de réunion / Lien visio" />
              </div>

              {/* Agenda items */}
              <div className="border-t pt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-semibold">Ordre du jour</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addAgendaItem}>
                    <Plus className="w-3 h-3 mr-1" />Ajouter un point
                  </Button>
                </div>
                {agendaDrafts.map((draft, idx) => (
                  <Card key={idx} className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Point {idx + 1}</span>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => removeAgendaDraft(idx)}>
                        <Trash2 className="w-3.5 h-3.5 text-destructive" />
                      </Button>
                    </div>
                    <Input placeholder="Titre du point" value={draft.title} onChange={(e) => updateAgendaDraft(idx, "title", e.target.value)} />
                    <Textarea placeholder="Description (optionnel)" className="min-h-[60px]" value={draft.description} onChange={(e) => updateAgendaDraft(idx, "description", e.target.value)} />
                    <div className="flex items-center gap-4">
                      <Select value={draft.nature} onValueChange={(v) => updateAgendaDraft(idx, "nature", v)}>
                        <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="information">Information</SelectItem>
                          <SelectItem value="decision">Solution</SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="flex-1">
                        <Label className="text-xs text-muted-foreground cursor-pointer flex items-center gap-1.5">
                          <FileUp className="w-3.5 h-3.5" />
                          Documents
                          <input type="file" multiple className="hidden" onChange={(e) => addFileToAgenda(idx, e.target.files)} />
                        </Label>
                      </div>
                    </div>
                    {draft.files.length > 0 && (
                      <div className="space-y-1">
                        {draft.files.map((f, fi) => (
                          <div key={fi} className="flex items-center justify-between text-xs bg-muted rounded px-2 py-1">
                            <span className="truncate">{f.name}</span>
                            <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => removeFileFromAgenda(idx, fi)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
              <Button onClick={handleCreate} disabled={!form.organ_id || !form.title || !form.session_date}>Créer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="ca">
        <TabsList>
          <TabsTrigger value="ca">Conseil d'Administration</TabsTrigger>
          <TabsTrigger value="audit">Comité d'Audit</TabsTrigger>
        </TabsList>
        <TabsContent value="ca" className="mt-4">
          {renderSessionsTable(caSessions)}
        </TabsContent>
        <TabsContent value="audit" className="mt-4">
          {renderSessionsTable(auditSessions)}
        </TabsContent>
      </Tabs>
    </div>
  );
}

const workflowSteps: { status: string; label: string; next?: string; nextLabel?: string; requiredRole?: string }[] = [
  { status: "brouillon", label: "Brouillon", next: "validee", nextLabel: "Valider l'ODJ", requiredRole: "president" },
  { status: "validee", label: "Validée", next: "tenue", nextLabel: "Marquer tenue" },
  { status: "tenue", label: "Tenue", next: "cloturee", nextLabel: "Clôturer" },
  { status: "cloturee", label: "Clôturée", next: "archivee", nextLabel: "Archiver" },
  { status: "archivee", label: "Archivée" },
];

function SessionDetailsPanel({ details, sessionId, sessionStatus, onRefresh }: { details: { agendaItems: any[]; attendees: any[] }; sessionId: string; sessionStatus: string; onRefresh: () => void }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const handleUploadDoc = async (agendaItemId: string, files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    for (const file of Array.from(files)) {
      const filePath = `${sessionId}/${agendaItemId}/${Date.now()}_${file.name}`;
      const { error: upErr } = await supabase.storage.from("session-documents").upload(filePath, file);
      if (!upErr) {
        await supabase.from("documents").insert([{
          session_id: sessionId,
          agenda_item_id: agendaItemId,
          name: file.name,
          file_path: filePath,
          file_size: file.size,
          mime_type: file.type,
          uploaded_by: user?.id,
        }]);
      }
    }
    toast({ title: "Document(s) ajouté(s)" });
    setUploading(false);
    onRefresh();
  };

  const advanceWorkflow = async () => {
    const current = workflowSteps.find(s => s.status === sessionStatus);
    if (!current?.next) return;
    const { error } = await supabase.from("sessions").update({ status: current.next as any }).eq("id", sessionId);
    if (error) toast({ title: "Erreur", description: error.message, variant: "destructive" });
    else { toast({ title: `Session passée à "${workflowSteps.find(s => s.status === current.next)?.label}"` }); onRefresh(); }
  };

  const currentStep = workflowSteps.find(s => s.status === sessionStatus);

  return (
    <div className="space-y-4">
      {/* Workflow progress */}
      <div className="flex items-center gap-1 flex-wrap">
        {workflowSteps.map((step, i) => {
          const isCurrent = step.status === sessionStatus;
          const isPast = workflowSteps.findIndex(s => s.status === sessionStatus) > i;
          return (
            <div key={step.status} className="flex items-center gap-1">
              <Badge className={isCurrent ? "bg-primary text-primary-foreground" : isPast ? "bg-emerald-100 text-emerald-800" : "bg-muted text-muted-foreground"}>
                {step.label}
              </Badge>
              {i < workflowSteps.length - 1 && <span className="text-muted-foreground">→</span>}
            </div>
          );
        })}
      </div>
      {currentStep?.next && (
        <Button size="sm" onClick={advanceWorkflow}>
          {currentStep.nextLabel}
        </Button>
      )}

      <div>
        <h4 className="font-semibold text-sm mb-2">Ordre du jour</h4>
        {details.agendaItems.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucun point à l'ordre du jour</p>
        ) : (
          <div className="space-y-2">
            {details.agendaItems.map((ai, idx) => (
              <div key={ai.id} className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{idx + 1}. {ai.title}</span>
                  <Badge variant="outline" className="text-xs">{ai.nature}</Badge>
                </div>
                {ai.description && <p className="text-xs text-muted-foreground">{ai.description}</p>}
                {ai.documents && ai.documents.length > 0 && (
                  <div className="space-y-1">
                    {ai.documents.map((doc: any) => (
                      <div key={doc.id} className="flex items-center gap-2 text-xs bg-background rounded px-2 py-1">
                        <Eye className="w-3 h-3 text-muted-foreground" />
                        <span className="truncate">{doc.name}</span>
                      </div>
                    ))}
                  </div>
                )}
                <Label className="text-xs cursor-pointer text-primary flex items-center gap-1">
                  <FileUp className="w-3 h-3" />
                  {uploading ? "Envoi..." : "Ajouter un document"}
                  <input type="file" multiple className="hidden" onChange={(e) => handleUploadDoc(ai.id, e.target.files)} disabled={uploading} />
                </Label>
              </div>
            ))}
          </div>
        )}
      </div>
      <div>
        <h4 className="font-semibold text-sm mb-2">Participants ({details.attendees.length})</h4>
        {details.attendees.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucun participant</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {details.attendees.map((a) => (
              <Badge key={a.id} variant={a.is_present ? "default" : "outline"} className="text-xs">
                {(a as any).members?.full_name}
                {a.is_present === true && " ✓"}
              </Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
