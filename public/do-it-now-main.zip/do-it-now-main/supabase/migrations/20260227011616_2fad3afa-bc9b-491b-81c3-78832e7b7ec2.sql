
-- Enum types
CREATE TYPE public.app_role AS ENUM ('admin', 'secretaire', 'president', 'membre', 'invite', 'auditeur');
CREATE TYPE public.organ_type AS ENUM ('ca', 'comite_audit');
CREATE TYPE public.session_type AS ENUM ('ordinaire', 'extraordinaire');
CREATE TYPE public.session_status AS ENUM ('brouillon', 'validee', 'tenue', 'cloturee', 'archivee');
CREATE TYPE public.agenda_nature AS ENUM ('information', 'decision');
CREATE TYPE public.vote_type AS ENUM ('unanimite', 'majorite', 'abstention');
CREATE TYPE public.action_status AS ENUM ('en_cours', 'en_retard', 'terminee', 'annulee');
CREATE TYPE public.member_quality AS ENUM ('pca', 'administrateur', 'president_comite', 'rapporteur', 'membre', 'autre');

-- Profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT NOT NULL DEFAULT '',
  email TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view all profiles" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- User roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Organs table
CREATE TABLE public.organs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type organ_type NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.organs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view organs" ON public.organs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage organs" ON public.organs FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Members table
CREATE TABLE public.members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organ_id UUID REFERENCES public.organs(id) ON DELETE CASCADE NOT NULL,
  full_name TEXT NOT NULL,
  quality member_quality NOT NULL DEFAULT 'membre',
  mandate_start DATE NOT NULL,
  mandate_end DATE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  email TEXT,
  phone TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view members" ON public.members FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins and secretaires can manage members" ON public.members FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Sessions table
CREATE TABLE public.sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organ_id UUID REFERENCES public.organs(id) ON DELETE CASCADE NOT NULL,
  session_type session_type NOT NULL DEFAULT 'ordinaire',
  title TEXT NOT NULL,
  session_date TIMESTAMPTZ NOT NULL,
  location TEXT,
  is_virtual BOOLEAN NOT NULL DEFAULT false,
  status session_status NOT NULL DEFAULT 'brouillon',
  convocation_sent BOOLEAN NOT NULL DEFAULT false,
  quorum_met BOOLEAN,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view sessions" ON public.sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins can manage sessions" ON public.sessions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Session attendees
CREATE TABLE public.session_attendees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE NOT NULL,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL,
  is_present BOOLEAN DEFAULT false,
  proxy_member_id UUID REFERENCES public.members(id),
  UNIQUE(session_id, member_id)
);
ALTER TABLE public.session_attendees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view attendees" ON public.session_attendees FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage attendees" ON public.session_attendees FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Agenda items (Ordre du jour)
CREATE TABLE public.agenda_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  presenter_member_id UUID REFERENCES public.members(id),
  nature agenda_nature NOT NULL DEFAULT 'information',
  order_index INTEGER NOT NULL DEFAULT 0,
  is_confidential BOOLEAN NOT NULL DEFAULT false,
  validated_by_president BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.agenda_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view agenda items" ON public.agenda_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage agenda" ON public.agenda_items FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Documents
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE,
  agenda_item_id UUID REFERENCES public.agenda_items(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT,
  mime_type TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  uploaded_by UUID REFERENCES auth.users(id),
  is_confidential BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view documents" ON public.documents FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage documents" ON public.documents FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Minutes (Procès-verbaux)
CREATE TABLE public.minutes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE NOT NULL UNIQUE,
  content TEXT,
  is_validated BOOLEAN NOT NULL DEFAULT false,
  validated_by UUID REFERENCES auth.users(id),
  validated_at TIMESTAMPTZ,
  pdf_path TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.minutes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view minutes" ON public.minutes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage minutes" ON public.minutes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Decisions
CREATE TABLE public.decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE NOT NULL,
  agenda_item_id UUID REFERENCES public.agenda_items(id) ON DELETE SET NULL,
  decision_number TEXT NOT NULL,
  text TEXT NOT NULL,
  vote_type vote_type,
  responsible_member_id UUID REFERENCES public.members(id),
  effective_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.decisions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view decisions" ON public.decisions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage decisions" ON public.decisions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Actions (suivi)
CREATE TABLE public.actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID REFERENCES public.decisions(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  responsible_member_id UUID REFERENCES public.members(id),
  due_date DATE,
  status action_status NOT NULL DEFAULT 'en_cours',
  completion_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.actions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view actions" ON public.actions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Secretaires and admins manage actions" ON public.actions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'secretaire'));

-- Audit log
CREATE TABLE public.audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  table_name TEXT,
  record_id UUID,
  details JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view audit log" ON public.audit_log FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'auditeur'));
CREATE POLICY "System can insert audit log" ON public.audit_log FOR INSERT TO authenticated WITH CHECK (true);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), NEW.email);
  -- Assign default role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'membre');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_members_updated_at BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_sessions_updated_at BEFORE UPDATE ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_minutes_updated_at BEFORE UPDATE ON public.minutes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_actions_updated_at BEFORE UPDATE ON public.actions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default organs
INSERT INTO public.organs (name, type, description) VALUES
  ('Conseil d''Administration', 'ca', 'Conseil d''Administration de la société'),
  ('Comité d''Audit', 'comite_audit', 'Comité d''Audit de la société');

-- Storage bucket for documents
INSERT INTO storage.buckets (id, name, public) VALUES ('session-documents', 'session-documents', false);

CREATE POLICY "Authenticated users can upload documents"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'session-documents');

CREATE POLICY "Authenticated users can view documents"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'session-documents');

CREATE POLICY "Admins and secretaires can delete documents"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'session-documents');
