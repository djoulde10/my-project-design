
-- Add old/new value columns to audit_log
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS old_values jsonb;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS new_values jsonb;

-- Create audit trigger function that logs all changes automatically
CREATE OR REPLACE FUNCTION public.audit_trigger_func()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _old_values jsonb := NULL;
  _new_values jsonb := NULL;
  _action text;
  _record_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    _action := 'DELETE';
    _old_values := to_jsonb(OLD);
    _record_id := OLD.id;
  ELSIF TG_OP = 'UPDATE' THEN
    _action := 'UPDATE';
    _old_values := to_jsonb(OLD);
    _new_values := to_jsonb(NEW);
    _record_id := NEW.id;
  ELSIF TG_OP = 'INSERT' THEN
    _action := 'INSERT';
    _new_values := to_jsonb(NEW);
    _record_id := NEW.id;
  END IF;

  INSERT INTO public.audit_log (user_id, action, table_name, record_id, old_values, new_values, details)
  VALUES (auth.uid(), _action, TG_TABLE_NAME, _record_id, _old_values, _new_values, jsonb_build_object('trigger', true));

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

-- Add audit triggers on all critical tables
CREATE TRIGGER audit_sessions
  AFTER INSERT OR UPDATE OR DELETE ON public.sessions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_agenda_items
  AFTER INSERT OR UPDATE OR DELETE ON public.agenda_items
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_documents
  AFTER INSERT OR UPDATE OR DELETE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_minutes
  AFTER INSERT OR UPDATE OR DELETE ON public.minutes
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_decisions
  AFTER INSERT OR UPDATE OR DELETE ON public.decisions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_actions
  AFTER INSERT OR UPDATE OR DELETE ON public.actions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_members
  AFTER INSERT OR UPDATE OR DELETE ON public.members
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_session_attendees
  AFTER INSERT OR UPDATE OR DELETE ON public.session_attendees
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
