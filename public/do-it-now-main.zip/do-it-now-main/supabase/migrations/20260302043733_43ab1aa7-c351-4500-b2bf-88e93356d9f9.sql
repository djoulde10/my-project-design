
-- Add new member quality value
ALTER TYPE public.member_quality ADD VALUE IF NOT EXISTS 'secretariat_juridique';

-- Create minutes_status enum
DO $$ BEGIN
  CREATE TYPE public.minutes_status AS ENUM ('en_attente', 'vote', 'adopte', 'adopte_et_signe');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Add pv_status column to minutes
ALTER TABLE public.minutes ADD COLUMN IF NOT EXISTS pv_status text NOT NULL DEFAULT 'en_attente';
