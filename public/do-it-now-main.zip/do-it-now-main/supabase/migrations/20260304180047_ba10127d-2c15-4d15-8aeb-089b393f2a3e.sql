
-- Rename table decisions to solutions
ALTER TABLE public.decisions RENAME TO solutions;

-- Rename columns
ALTER TABLE public.solutions RENAME COLUMN decision_number TO numero_solution;
ALTER TABLE public.solutions RENAME COLUMN text TO texte;
ALTER TABLE public.solutions RENAME COLUMN responsible_member_id TO responsable_execution_id;
ALTER TABLE public.solutions RENAME COLUMN effective_date TO date_effet;

-- Rename foreign key column in actions table
ALTER TABLE public.actions RENAME COLUMN decision_id TO solution_id;

-- Create sequence for auto-numbering
CREATE SEQUENCE IF NOT EXISTS solutions_numero_seq START 1;

-- Create trigger function for auto-numbering
CREATE OR REPLACE FUNCTION public.auto_numero_solution()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.numero_solution IS NULL OR NEW.numero_solution = '' THEN
    NEW.numero_solution := 'SOL-' || LPAD(nextval('solutions_numero_seq')::text, 4, '0');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_auto_numero_solution
BEFORE INSERT ON public.solutions
FOR EACH ROW
EXECUTE FUNCTION public.auto_numero_solution();

-- Update audit trigger for renamed table
DROP TRIGGER IF EXISTS audit_solutions ON public.solutions;
CREATE TRIGGER audit_solutions
AFTER INSERT OR UPDATE OR DELETE ON public.solutions
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

-- Update audit trigger for actions (decision_id renamed)
DROP TRIGGER IF EXISTS audit_actions ON public.actions;
CREATE TRIGGER audit_actions
AFTER INSERT OR UPDATE OR DELETE ON public.actions
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
